package edu.xjtu.dbhw.shiyan2.ques3;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Scan;

import org.apache.hadoop.hbase.mapreduce.TableMapReduceUtil;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;


public class HBaseMapReduceExper {

	public static String SOURCE_TABLE_NAME = "Book";
	public static String SORTED_TABLE_NAME = "BookSorted";
	public static String FAMILY_NAME_BOOK_INFO = "BookInfo";
	public static String COLUMN_NAME_PRICE = "Price";
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration conf = HBaseConfiguration.create();
		try {
			// set up job
			Job job = new Job(conf, "sort book");
			Scan scan = new Scan();
			scan.addColumn(Bytes.toBytes(FAMILY_NAME_BOOK_INFO), Bytes.toBytes(COLUMN_NAME_PRICE));
			// set mapper
			TableMapReduceUtil.initTableMapperJob(SOURCE_TABLE_NAME, scan, BookMapper.class, IntWritable.class, Text.class, job);
			// set reducer
			TableMapReduceUtil.initTableReducerJob(SORTED_TABLE_NAME, BookReducer.class, job);
			System.exit(job.waitForCompletion(true) ? 0 : 1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
