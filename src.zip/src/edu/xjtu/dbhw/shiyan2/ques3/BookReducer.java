package edu.xjtu.dbhw.shiyan2.ques3;

import java.io.IOException;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableReducer;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;

public class BookReducer extends TableReducer<IntWritable, Text, ImmutableBytesWritable>{
	@Override
	public void reduce(IntWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException{
		// output sorted result in console
		//System.out.println("values: " + values.iterator().next().toString());
		String[] bookNameBytes = values.iterator().next().toString().split(" ");
		String bookName = "";
		for (int i = 0; i < bookNameBytes.length; i++){
			bookName += (char)Integer.parseInt(bookNameBytes[i], 16);
		}
		String price = key.toString() + "";
		System.out.println("Book: " + bookName + ", Price: " + price);
		// output to hbase
		Put put = new Put(Bytes.toBytes(bookName));
		put.add(Bytes.toBytes(HBaseMapReduceExper.FAMILY_NAME_BOOK_INFO), Bytes.toBytes(HBaseMapReduceExper.COLUMN_NAME_PRICE), Bytes.toBytes(price));
		context.write(null, put);
	}
}
