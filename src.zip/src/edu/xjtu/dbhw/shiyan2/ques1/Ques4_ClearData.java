package edu.xjtu.dbhw.shiyan2.ques1;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;

public class Ques4_ClearData {

	@SuppressWarnings("deprecation")
	public void clearTable() throws IOException{
		String tableName = "shiyan2";
		Configuration conf = HBaseConfiguration.create();
		HTable table = new HTable(conf, tableName);
		HBaseAdmin hAdmin = new HBaseAdmin(conf);
		if (hAdmin.tableExists(tableName)){
			hAdmin.disableTable(tableName); // close table
			hAdmin.deleteTable(tableName); // delete table
			HTableDescriptor tableDescriptor = new HTableDescriptor(tableName);
			hAdmin.createTable(tableDescriptor); // create the same table
			System.out.println("clear sucessfully");
		}else{
			System.out.println("clear fail");
		}
		hAdmin.close();
		table.close();
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ques4_ClearData q4cd = new Ques4_ClearData();
		try {
			q4cd.clearTable();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
