package edu.xjtu.dbhw.shiyan2.ques1;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;

public class Ques2_ScanTable {

	@SuppressWarnings("deprecation")
	public void ScanTable() throws IOException{
		String tableName = "myFirstTable";
		Configuration conf = HBaseConfiguration.create();
		HTable table = new HTable(conf, tableName);
		Scan scan = new Scan();
		ResultScanner results = table.getScanner(scan);
		for (Result result : results){
			for (KeyValue rowKV : result.raw()){
				System.out.print("row key: " + new String(rowKV.getRow()) + ", ");
				System.out.print("timestamp: " + rowKV.getTimestamp() + ", ");
				System.out.print("col family: " + new String(rowKV.getFamily()) + ", ");
				System.out.print("col: " + new String(rowKV.getQualifier()) + ", ");
				System.out.println("value: " + new String(rowKV.getValue()));
			}
		}
		table.close();
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ques2_ScanTable q2st = new Ques2_ScanTable();
		try {
			q2st.ScanTable();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
