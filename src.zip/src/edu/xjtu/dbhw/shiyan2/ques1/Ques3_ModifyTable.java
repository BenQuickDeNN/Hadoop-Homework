package edu.xjtu.dbhw.shiyan2.ques1;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

public class Ques3_ModifyTable {

	public void addRow() throws IOException{
		String tableName = "shiyan2";
		String rowKey = "key1";
		String colFamily = "cf1";
		String column = "col1";
		String value = "value11";
		
		Configuration conf = HBaseConfiguration.create();
		HTable table = new HTable(conf, tableName);
		Put put = new Put(Bytes.toBytes(rowKey));
		put.add(Bytes.toBytes(colFamily), Bytes.toBytes(column), Bytes.toBytes(value));
		table.put(put);
		
		table.close();
	}
	public void deleteRow() throws IOException{
		String tableName = "shiyan2";
		String rowKey = "key4";
		Configuration conf = HBaseConfiguration.create();
		HTable table = new HTable(conf, tableName);
		Delete del = new Delete(Bytes.toBytes(rowKey));
		table.delete(del);
		System.out.println("delete row successfully");
		table.close();
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ques3_ModifyTable q3mt = new Ques3_ModifyTable();
		try {
			q3mt.addRow();
			// q3mt.deleteRow();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
