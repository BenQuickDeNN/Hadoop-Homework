package edu.xjtu.dbhw.shiyan2.ques1;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;

public class Ques5_CountRow {

	public void countRow() throws IOException{
		String tableName = "shiyan2";
		Configuration conf = HBaseConfiguration.create();
		HTable table = new HTable(conf, tableName);
		Scan scan = new Scan();
		ResultScanner results = table.getScanner(scan);
		int count = 0;
		for (Result result : results){
			++count;
		}
		System.out.println("count = " + count);
		table.close();
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ques5_CountRow q5cr = new Ques5_CountRow();
		try {
			q5cr.countRow();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
