package edu.xjtu.dbhw.shiyan2.ques2;

public class SourceCourse {

	/**
	 * 
	 * @return
	 */
	public static int getLength(){
		return course.length;
	}
	/**
	 * random course name
	 */
	public static String[] course = {
		"Algorithm",
		"Big Data",
		"Database System",
		"Machine Learning",
		"Pattern Reconition",
		"Computer Vision",
		"Artificial Intelligence",
		"French",
		"English",
		"Spanish",
		"Janpanese",
		"Germany",
		"Russian",
		"Portugese"
	};
}
