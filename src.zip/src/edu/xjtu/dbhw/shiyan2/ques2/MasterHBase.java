package edu.xjtu.dbhw.shiyan2.ques2;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Random;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.RetriesExhaustedWithDetailsException;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;

public class MasterHBase {
	public static final String TABLE_NAME_STUDENT = "Student";
	public static final String TABLE_NAME_COURSE = "Course";
	public static final String TABLE_NAME_SC = "SC";
	
	public static final String FAMILY_NAME_STUDENT_INFO = "StudentInfo";
	public static final String COLUMN_NAME_STUDENT_NAME = "S_Name";
	public static final String COLUMN_NAME_STUDENT_SEX = "S_Sex";
	public static final String COLUMN_NAME_STUDENT_AGE = "S_Age";
	
	public static final String FAMILY_NAME_COURSE_INFO = "CourseInfo";
	public static final String COLUMN_NAME_COURSE_NAME = "C_Name";
	public static final String COLUMN_NAME_COURSE_CREDIT = "C_Credit";
	
	public static final String FAMILY_NAME_SC_INFO = "SCInfo";
	public static final String COLUMN_NAME_SC_SNO = "SC_Sno";
	public static final String COLUMN_NAME_SC_CNO = "SC_Cno";
	public static final String COLUMN_NAME_SC_SCORE = "SC_Score";
	/**
	 * create hbase table
	 * @param tableName table name
	 * @param fields column family
	 * @throws IOException 
	 * @throws ZooKeeperConnectionException 
	 * @throws MasterNotRunningException 
	 */
	public void createTable(String tableName, String[] fields) throws MasterNotRunningException, ZooKeeperConnectionException, IOException{
		Configuration conf = HBaseConfiguration.create();
		HBaseAdmin hAdmin = new HBaseAdmin(conf);
		// check if the table is exist
		if (hAdmin.tableExists(tableName)){
			// delete the previous table
			System.out.println("found previous table " + tableName + ", delete it.");
			hAdmin.disableTable(tableName); // close table
			hAdmin.deleteTable(tableName); // delete table
			System.out.println("deleting completed.");
		}
		// create new table
		HTableDescriptor tableDesc = new HTableDescriptor(tableName);
		for (String colFamily : fields){
			tableDesc.addFamily(new HColumnDescriptor(colFamily));
		}
		hAdmin.createTable(tableDesc);
		System.out.println("created new table " + tableName + ".");
		
		hAdmin.close();
	}
	/**
	 * add record to table
	 * @param tableName table name
	 * @param row row key
	 * @param fields column family
	 * @param values values
	 * @throws IOException 
	 */
	public void addRecord(String tableName, String row, String[] fields, String[] values) throws IOException{
		for (int i = 0; i < fields.length; i++){
			addRow(tableName, row, fields[i], values[i]);
		}
		System.out.println("add record complete");
	}
	/**
	 * add record to each row
	 * @param tableName table name
	 * @param rowKey row key
	 * @param colFamily column 
	 * @param value value
	 * @throws IOException
	 */
	private void addRow(String tableName, String rowKey, String colFamily, String value) throws IOException{
		Configuration conf = HBaseConfiguration.create();
		HTable table = new HTable(conf, tableName);
		String familyName = colFamily.substring(0, colFamily.indexOf(":"));
		String column = colFamily.substring(colFamily.indexOf(":") + 1);
		
		Put put = new Put(Bytes.toBytes(rowKey));
		put.add(Bytes.toBytes(familyName), Bytes.toBytes(column), Bytes.toBytes(value));
		table.put(put);
		
		table.close();
		System.out.println("add row " + rowKey + " to table " + tableName);
	}
	/**
	 * add record randomly
	 * @param tableName table name
	 * @param amount the amount of new record
	 * @throws IOException 
	 */
	public void randAddRecord(String tableName, int amount) throws IOException{
		for (int i = 0; i < amount; i++){
			switch (tableName){
				case TABLE_NAME_STUDENT:
					// create student number
					int s_number = 2015001;
					String sNo = (s_number + countRow(tableName)) + "";
					// create student name
					String sName = SourceEn.namesEn[i * 30 % SourceEn.getLength()];
					// create random sex
					String sSex = SourceSex.sex[new Random().nextInt(SourceSex.getLength() - 1 - 0) + 0];
					// create random age between 20 to 30
					String sAge = new Random().nextInt(30 - 20) + 20 + "";
					// add row
					addRow(tableName, sNo, FAMILY_NAME_STUDENT_INFO + ":" + COLUMN_NAME_STUDENT_NAME, sName);
					addRow(tableName, sNo, FAMILY_NAME_STUDENT_INFO + ":" + COLUMN_NAME_STUDENT_SEX, sSex);
					addRow(tableName, sNo, FAMILY_NAME_STUDENT_INFO + ":" + COLUMN_NAME_STUDENT_AGE, sAge);
					break;
				case TABLE_NAME_COURSE:
					// create course number
					int c_number = 12301;
					String cNo = (c_number + countRow(tableName)) + "";
					// create random course name
					String cName = SourceCourse.course[i % SourceCourse.getLength()];
					// create random credit
					float f_credit = (float)(new Random().nextInt(9 - 1) + 1);
					NumberFormat formatter = new DecimalFormat("0.0");
					String cCredit = formatter.format(f_credit);
					// add row
					addRow(tableName, cNo, FAMILY_NAME_COURSE_INFO + ":" + COLUMN_NAME_COURSE_NAME, cName);
					addRow(tableName, cNo, FAMILY_NAME_COURSE_INFO + ":" + COLUMN_NAME_COURSE_CREDIT, cCredit);
					break;
				case TABLE_NAME_SC:
					// create SC serial number
					String scNo = (1 + countRow(tableName)) + "";
					// create student number and course number
					final int cAmount = countRow(TABLE_NAME_COURSE);
					final int sAmount = countRow(TABLE_NAME_STUDENT);
					int i_sno = 2015001 + ((i / cAmount) % sAmount);
					int i_cno = 123001 + (i % cAmount);
					String scSNo = i_sno + "";
					String scCNo = i_cno + "";
					// create SC score
					String scScore = new Random().nextInt(100 - 0) + 0 + "";
					// add row
					addRow(tableName, scNo, FAMILY_NAME_SC_INFO + ":" + COLUMN_NAME_SC_SNO, scSNo);
					addRow(tableName, scNo, FAMILY_NAME_SC_INFO + ":" + COLUMN_NAME_SC_CNO, scCNo);
					addRow(tableName, scNo, FAMILY_NAME_SC_INFO + ":" + COLUMN_NAME_SC_SCORE, scScore);
					break;
				default:
					System.err.println("no table selected");
					break;
			}
		}
	}
	/**
	 * count the amount of existed record
	 * @param tableName table name
	 * @return amount
	 * @throws IOException 
	 */
	public int countRow(String tableName) throws IOException{
		Configuration conf = HBaseConfiguration.create();
		HTable table = new HTable(conf, tableName);
		Scan scan = new Scan();
		ResultScanner results = table.getScanner(scan);
		int count = 0;
		for (Result result : results){
			++count;
		}
		table.close();
		return count;
	}
	/**
	 * scan table
	 * @param tableName table name
	 * @param column column name
	 * @throws IOException 
	 */
	public void scanColumn(String tableName, String column) throws IOException{
		Configuration conf = HBaseConfiguration.create();
		HTable table = new HTable(conf, tableName);
		Scan scan = new Scan();
		ResultScanner results = table.getScanner(scan);
		
		for (Result result : results){
			for (KeyValue rowKV : result.raw()){
				// check if column equals a family name
				// or a qualifier name
				if (column.equals(new String(rowKV.getFamily()))){
					System.out.println("row: " + new String(rowKV.getRow()) + ", col: " + column + ":" + new String(rowKV.getQualifier()) + ", value: " + new String(rowKV.getValue()));
				}
				else if (column.equals(new String(rowKV.getFamily()) + ":" + new String(rowKV.getQualifier()))){
					System.out.println("row: " + new String(rowKV.getRow()) + ", col: " + column + ", value: " + new String(rowKV.getValue()));
				}
			}
		}
		
		table.close();
		System.out.println("scanning complete!");
	}
	/**
	 * modify data
	 * @param tableName table name
	 * @param row row key
	 * @param column column name
	 * @throws IOException 
	 */
	public void modifyData(String tableName, String row, String column, String newValue) throws IOException{
		Configuration conf = HBaseConfiguration.create();
		HTable table = new HTable(conf, tableName);
		// firstly delete, then add
		Delete del = new Delete(Bytes.toBytes(row));
		String family = column.substring(0, column.indexOf(":"));
		String qualifier = column.substring(column.indexOf(":") + 1);
		del.deleteColumn(Bytes.toBytes(family), Bytes.toBytes(qualifier));
		table.delete(del);
		// add
		Put put = new Put(Bytes.toBytes(row));
		put.add(Bytes.toBytes(family), Bytes.toBytes(qualifier), Bytes.toBytes(newValue));
		table.put(put);
		
		table.close();
	}
	/**
	 * delete record
	 * @param tableName table name
	 * @param row row key
	 * @throws IOException 
	 */
	public void deleteRow(String tableName, String row) throws IOException{
		Configuration conf = HBaseConfiguration.create();
		HTable table = new HTable(conf, tableName);
		Delete del = new Delete(Bytes.toBytes(row));
		table.delete(del);
		
		table.close();
		System.out.println("delete " + row + " from " + tableName);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MasterHBase mhb = new MasterHBase();
		// create table
		/*
		try {
			// student
			String[] fields_student = {MasterHBase.FAMILY_NAME_STUDENT_INFO};
			mhb.createTable(MasterHBase.TABLE_NAME_STUDENT, fields_student);
			// course
			String[] fields_course = {MasterHBase.FAMILY_NAME_COURSE_INFO};
			mhb.createTable(MasterHBase.TABLE_NAME_COURSE, fields_course);
			// sc
			String[] fields_sc = {MasterHBase.FAMILY_NAME_SC_INFO};
			mhb.createTable(MasterHBase.TABLE_NAME_SC, fields_sc);
		} catch (MasterNotRunningException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ZooKeeperConnectionException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		*/
		// generate data for experiment
		/*
		try {
			mhb.randAddRecord(MasterHBase.TABLE_NAME_STUDENT, 30);
			mhb.randAddRecord(MasterHBase.TABLE_NAME_COURSE, 10);
			mhb.randAddRecord(MasterHBase.TABLE_NAME_SC, 150);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		// example: addRecord
		/*
		try {
			String[] s_Fields = {"StudentInfo:S_Name", "StudentInfo:S_Sex","StudentInfo:S_Age"};
			String[] s_Values = {"Liying", "male", "23"};
			String s_Row = (2015001 + mhb.countRow(MasterHBase.TABLE_NAME_STUDENT)) + "";
			mhb.addRecord(MasterHBase.TABLE_NAME_STUDENT, s_Row, s_Fields, s_Values);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		// example: scanColumn, columnFamily
		/*
		try {
			mhb.scanColumn(MasterHBase.TABLE_NAME_STUDENT, MasterHBase.FAMILY_NAME_STUDENT_INFO);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		// example: scanColumn, column
		/*
		try {
			mhb.scanColumn(MasterHBase.TABLE_NAME_STUDENT, MasterHBase.FAMILY_NAME_STUDENT_INFO + ":" + MasterHBase.COLUMN_NAME_STUDENT_NAME);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		// example: modifyData
		/*
		try {
			mhb.modifyData(MasterHBase.TABLE_NAME_STUDENT, "2015001", MasterHBase.FAMILY_NAME_STUDENT_INFO + ":" + MasterHBase.COLUMN_NAME_STUDENT_SEX, "female");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		// example: deleteRow
		try {
			mhb.deleteRow(MasterHBase.TABLE_NAME_SC, "99");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
