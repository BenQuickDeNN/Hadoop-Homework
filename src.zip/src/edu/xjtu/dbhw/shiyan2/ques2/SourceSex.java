package edu.xjtu.dbhw.shiyan2.ques2;

public class SourceSex {
	public static int getLength(){
		return sex.length;
	}
	public static String[] sex = {
		"male",
		"female"
	};
}
